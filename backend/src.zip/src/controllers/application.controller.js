import { db } from "../config/db.js";
import axios from "axios";

const APP_CONFIG = {
  HRIS: {
    token: process.env.HRIS_TOKEN,
    base_url: "https://personasys.triasmitra.com",
  },
  AMS: {
    token: process.env.AMS_TOKEN,
    base_url: "https://ams.triasmitra.com",
  },
  IMS: {
    token: process.env.IMS_TOKEN,
    base_url: "https://ims.triasmitra.com",
  },
};

/* ================= GET ALL ================= */
export const getApplications = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM applications WHERE deleted_at IS NULL ORDER BY code ASC"
    );

    res.json({
      success: true,
      data: rows,
    });
  } catch (err) {
    console.error("GET APPLICATIONS ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch applications",
    });
  }
};

/* ================= GET BY ID ================= */
export const getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;

    const [[app]] = await db.query(
      "SELECT * FROM applications WHERE id = ? AND deleted_at IS NULL",
      [id]
    );

    if (!app) {
      return res.status(404).json({
        success: false,
        message: "Application not found",
      });
    }

    res.json({
      success: true,
      data: app,
    });
  } catch (err) {
    console.error("GET APPLICATION ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch application",
    });
  }
};

/* ================= GET BY CODE ================= */
export const getApplicationByCode = async (req, res) => {
  try {
    const { code } = req.params;

    const [[app]] = await db.query(
      `
      SELECT *
      FROM applications
      WHERE code = ?
      AND deleted_at IS NULL
      `,
      [code]
    );

    if (!app) {
      return res.status(404).json({
        success: false,
        message: "Application not found",
      });
    }

    res.json({
      success: true,
      data: app,
    });
  } catch (err) {
    console.error("GET APPLICATION BY CODE ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch application",
    });
  }
};

/* ================= CREATE ================= */
export const createApplication = async (req, res) => {
  try {
    const { owner, code, name, url, color, icon } = req.body;

    const [result] = await db.query(
      `INSERT INTO applications
      (owner, code, name, url, color, icon)
      VALUES (?, ?, ?, ?, ?, ?)`,
      [owner, code, name, url, color, icon]
    );

    const insertedId = result.insertId;

    const [rows] = await db.query(
      `SELECT * FROM applications WHERE id = ?`,
      [insertedId]
    );

    res.status(201).json({
      success: true,
      message: "Application created",
      data: rows[0],
    });
  } catch (err) {
    console.error("CREATE APPLICATION ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to create application",
    });
  }
};

/* ================= UPDATE ================= */
export const updateApplication = async (req, res) => {
  try {
    const { id } = req.params;

    const fields = [];
    const values = [];

    const allowedFields = [
      "owner",
      "name",
      "url",
      "color",
      "icon",
    ];

    for (const key of allowedFields) {
      if (req.body[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(req.body[key]);
      }
    }

    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No fields to update",
      });
    }

    values.push(id);

    const [result] = await db.query(
      `UPDATE applications
       SET ${fields.join(", ")}
       WHERE id = ? AND deleted_at IS NULL`,
      values
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "Application not found",
      });
    }

    res.json({
      success: true,
      message: "Application updated",
    });
  } catch (err) {
    console.error("UPDATE APPLICATION ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to update application",
    });
  }
};

/* ================= SOFT DELETE ================= */
export const deleteApplication = async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.query(
      `UPDATE applications
       SET deleted_at = NOW()
       WHERE id = ? AND deleted_at IS NULL`,
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "Application not found",
      });
    }

    res.json({
      success: true,
      message: "Application deleted",
    });
  } catch (err) {
    console.error("DELETE APPLICATION ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to delete application",
    });
  }
};

export const getImsRoles = async (req, res) => {
  try {
    const response = await axios.get(
      process.env.IMS_URL + "/get-hierarchy",
      {
        headers: {
          Authorization: `Bearer ${process.env.IMS_API_KEY}`,
        },
      }
    );

    res.json({
      success: true,
      data: response.data,
    });

  } catch (err) {
    console.error("IMS ERROR STATUS:", err.response?.status);
    console.error("IMS ERROR DATA:", err.response?.data);
    console.error("IMS ERROR MESSAGE:", err.message);

    res.status(500).json({
      success: false,
      message: "Failed to fetch IMS roles",
    });
  }
};

export const getAmsRoles = async (req, res) => {
  try {
    const response = await axios.get(
      process.env.AMS_URL + "/get-role",
      {
        headers: {
          Authorization: `Bearer ${process.env.AMS_API_KEY}`,
        },
      }
    );

    res.json({
      success: true,
      data: response.data,
    });

  } catch (err) {
    console.error("GET AMS ROLES ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch AMS roles",
    });
  }
};

export const getAmsLocations = async (req, res) => {
  try {
    const response = await axios.get(
      process.env.AMS_URL + "/get-location",
      {
        headers: {
          Authorization: `Bearer ${process.env.AMS_API_KEY}`,
        },
      }
    );

    res.json({
      success: true,
      data: response.data,
    });

  } catch (err) {
    console.error("GET AMS LOCATIONS ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch AMS locations",
    });
  }
};

export const getCmsRoles = async (req, res) => {
  try {
    const response = await axios.get(
      process.env.CMS_URL + "/get-role",
      {
        headers: {
          Authorization: `Bearer ${process.env.CMS_API_KEY}`,
          "Accept": "application/json",
        },
      }
    );

    res.json({
      success: true,
      data: response.data,
    });

  } catch (err) {
    console.error("GET CMS ROLES ERROR:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch CMS roles",
    });
  }
};

// export const redirectToApplication = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const { code } = req.params;

//     const [[app]] = await db.query(
//       `
//       SELECT a.url
//       FROM applications a
//       JOIN user_applications ua
//         ON ua.application_id = a.id
//       WHERE ua.username = ?
//         AND a.code = ?
//       LIMIT 1
//       `,
//       [userId, code]
//     );

//     if (!app) {
//       return res.status(403).json({
//         success: false,
//         message: "Akses aplikasi ditolak",
//       });
//     }

//     return res.json({
//       success: true,
//       redirect_url: app.url,
//     });
//   } catch (err) {
//     console.error("REDIRECT ERROR:", err);
//     return res.status(500).json({
//       success: false,
//       message: "Gagal melakukan redirect",
//     });
//   }
// };

// export const redirectToApplication = async (req, res) => {
//   try {
//     const userId = req.user.id;
//     const nik = req.user.nik;
//     const { code } = req.params;

//     const config = APP_CONFIG[code];

//     if (!config) {
//       return res.status(404).json({
//         success: false,
//         message: "Application not supported",
//       });
//     }

//     // cek akses + ambil role
//     const [[access]] = await db.query(
//       `
//       SELECT ar.id AS role_id, ar.name AS role_name
//       FROM user_applications ua
//       JOIN application_roles ar 
//         ON ar.id = ua.application_roles_id
//       JOIN applications a 
//         ON a.id = ua.application_id
//       WHERE ua.username = ?
//         AND a.code = ?
//       LIMIT 1
//       `,
//       [userId, code]
//     );

//     if (!access) {
//       return res.status(403).json({
//         success: false,
//         message: "Akses aplikasi ditolak",
//       });
//     }

//     // call external SSO API
//     const response = await axios.get(
//       `${config.base_url}/api/public/get-token/${nik}`,
//       {
//         headers: {
//           Authorization: `Bearer ${config.token}`,
//         },
//       }
//     );

//     const accessToken = response.data?.result?.access_token;

//     if (!accessToken) {
//       return res.status(403).json({
//         success: false,
//         message: "User tidak memiliki akun di aplikasi tujuan",
//       });
//     }

//     return res.json({
//       success: true,
//       data: {
//         redirect_url: `${config.base_url}/sso/${accessToken}`,
//         application: code.toUpperCase(),
//         role: {
//           id: access.role_id,
//           name: access.role_name,
//         },
//       },
//     });
//   } catch (err) {
//     console.error("SSO REDIRECT ERROR:", err.message);

//     return res.status(500).json({
//       success: false,
//       message: "Gagal melakukan redirect SSO",
//     });
//   }
// };

export const redirectToApplication = async (req, res) => {
  try {
    const username = String(req.user.username).trim();
    const nik = username; // kalau memang NIK = username
    const rawCode = req.params.code;
    const code = rawCode.trim().toLowerCase();

    // mapping hardcode sementara
    let baseUrl = "";
    let token = "";

    if (code === "hris" || code === "hrisnew") {
      baseUrl = "https://personasys.triasmitra.com";
      token = "9592fabb0d0a7f63c913c3828ba0c895472e14668720a5018662390829c085c9";
    } else if (code === "ams") {
      baseUrl = "https://ams.triasmitra.com";
      token = "iCI0YUAb0hu+2HF62lR_xs9FUsguF3OI6BqU2O33vP46fq$AO42UAE647vCeu4Shxfw";
    } else if (code === "ims") {
      baseUrl = "https://ims.triasmitra.com";
      token = "KFhNebzV8EvLWTyWYZ0XPKafNGDwtANTN7WzZtka_TfGTqPQtmANLiRfMtCI8JKyxg9";
    } else if (code === "cms") {
      baseUrl = "https://cms.triasmitra.com";
      token = "9e6d3c1f7a4b8d2e5f1c9a7b3e6d4f8a2c1e7b9d5f3a6c8e4b1d7a2f9c6e3b5";
    } else if (code === "aas") {
      baseUrl = "https://aas.triasmitra.com";
      token = "a3f9d2b4c1e6f7890a1b2c3d4e5f60718293a4b5c6d7e8f90123456789abcdef";
    } else if (code === "qms") {
      baseUrl = "https://qms.triasmitra.com";
      token = "9f3c8a1d7e4b2f5a6c0d1e8b3a9f7c24e5d6b8a1c3f9e0d7a2b4c6e8f1a3d5b7";
    }
    else {
      return res.status(404).json({
        success: false,
        message: "Application not supported",
      });
    }

    console.log("=== DEBUG SSO ===");
    console.log("username from token:", username);
    console.log("code from params:", code);

    // cek akses user berdasarkan username
    const [[access]] = await db.query(
      `
        SELECT ua.id, ua.role_name
        FROM user_applications ua
        JOIN applications a 
          ON a.id = ua.application_id
        WHERE TRIM(LOWER(ua.username)) = TRIM(LOWER(?))
          AND TRIM(LOWER(a.code)) = TRIM(LOWER(?))
        LIMIT 1
      `,
      [username, code]
    )

    console.log("access result:", access); // lihat isinya apa

    if (!access) {
      return res.status(403).json({
        success: false,
        message: "Akses aplikasi ditolak",
      });
    }

    console.log("Calling CMS API:", `${baseUrl}/api/public/get-token/${nik}`);
    console.log("With token:", token);

    const targetIdentifier = code === "qms" ? access.role_name : nik;
    
    // call external SSO API
    const response = await axios.get(
      `${baseUrl}/api/public/get-token/${targetIdentifier}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("CMS API status:", response.status);
    console.log("CMS API response:", JSON.stringify(response.data));

    const accessToken = response.data?.result?.access_token;

    if (!accessToken) {
      return res.status(403).json({
        success: false,
        message: "User tidak memiliki akun di aplikasi tujuan",
      });
    }

    return res.json({
      success: true,
      data: {
        redirect_url: `${baseUrl}/sso/${accessToken}`,
        application: code.toUpperCase(),
        role: {
          id: access.role_id,
          name: access.role_name,
        },
      },
    });
  } catch (err) {
    console.error("SSO REDIRECT ERROR:", err.response?.data || err.message);
    console.error("SSO REDIRECT STATUS:", err.response?.status); // tambah ini
    console.error("SSO REDIRECT URL:", err.config?.url);         // tambah ini

    return res.status(500).json({
      success: false,
      message: "Gagal melakukan redirect SSO TEST",
      _debug: {
        error_message: err.message,
        error_status: err.response?.status ?? null,
        error_url: err.config?.url ?? null,
        error_response: err.response?.data ?? null,
        target_identifier: typeof targetIdentifier !== 'undefined' ? targetIdentifier : 'not set',
        base_url: baseUrl,
        code: code,
      }
    });
  }
};

